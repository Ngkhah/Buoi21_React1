import React, { Component } from 'react'

export default class Navigation extends Component {
   
   
   
   
   
    render() {
        return (
            <div className="bg-success text-white display-4 navigation">
                Navigation component
            </div>
        )
    }
}
