// import logo from './logo.svg';
import './App.css';
// import DemoComponent from './Components/DemoComponent';
// import DemoFComponent from './Components/DemoFComponent';
// import BaiTapComponent from './Components/BaiTapComponent/BaiTapComponent';
// import BaiTapLayoutBootstrap from './Components/BaiTapLayoutBootstrap/BaiTapLayoutBootstrap';

// import DataBinding from './DataBinding/DataBinding';
// import DataBindingReactFunc from './DataBinding/DataBindingReactFunc';
// import HandleEvent from './HandleEvent/HandleEvent';
// import RenderWithState from './RenderWithState/RenderWithState';
// import BaiTapChonXe from './RenderWithState/BaiTapChonXe';
import RenderWithMap from './RenderWithMap/RenderWithMap';
function App() { //Component gốc của ứng dụng
  
  return (
    <div className="App">
        {/* <BaiTapComponent /> */}
        {/* <BaiTapLayoutBootstrap /> */}
        {/* <DataBinding />
        <DataBindingReactFunc /> */}
        {/* <HandleEvent /> */}
        {/* <RenderWithState /> */}

        {/* <BaiTapChonXe /> */}
        <RenderWithMap />
    </div>
  );
}

export default App;
